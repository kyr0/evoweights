/* Geometry and event contract tests in the live, unmodified-policy Doom engine. */
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createArena} from '../dist/arena.mjs';

const a=await createArena({seed:9000,readAsset:n=>readFile(new URL('../dist/'+n,import.meta.url))});
const norm=deg=>(deg+540)%360-180;
const close=(x,y,eps=.0002)=>assert.ok(Math.abs(x-y)<=eps,`${x} != ${y}`);
function checkPose(s){
  assert.deepEqual(s.pose,{x:s.x,y:s.y,yawDeg:s.angle});
  assert.equal(s.actors.length,s.threat.visibleCount);
  assert.equal(s.actors.some(()=>true),s.features.slice(0,9).some(x=>x>0));
  if(s.actors.length)assert.equal(s.actors[0].id,s.threat.id);
  let nearest=-1;
  const ids=new Set();
  for(const t of s.actors){
    assert.ok(t.id>0&&!ids.has(t.id));ids.add(t.id);
    assert.ok(t.distance>=nearest);nearest=t.distance;
    close(Math.hypot(t.worldX-s.x,t.worldY-s.y),t.distance);
    close(norm(Math.atan2(t.worldY-s.y,t.worldX-s.x)*180/Math.PI-t.bearingDeg),0);
    close(norm(t.bearingDeg-s.angle),t.relativeYawDeg);
    close(Math.atan(t.x)*180/Math.PI,t.screenBearingDeg);
    assert.ok(t.x>=-1&&t.x<=1);
  }
}
function movement(action,back=false,forward=false){
  a.reset(9000);
  let s;
  for(let i=0;i<8;i++)s=a.step(action,back,forward);
  return {x:s.x,y:s.y,yaw:s.angle,ammo:s.ammo,prev:[...s.features].slice(11),shots:s.telemetry.shots};
}
const movements={forward:movement(3,false,true),back:movement(3,true),idle:movement(3),left:movement(0),right:movement(1)};
assert.ok(movements.forward.x>60&&movements.back.x< -60);
assert.equal(movements.idle.x,0);assert.equal(movements.idle.y,0);
assert.equal(movements.idle.yaw,0);assert.equal(movements.idle.shots,0);
assert.deepEqual(movements.forward.prev,[0,0,0]);
assert.ok(norm(movements.left.yaw)>0&&norm(movements.right.yaw)<0);
assert.throws(()=>a.step(3,true,true));
const totals={observations:0,visibleActorObservations:0,damage:0,damageWhileNoVisibleActor:0,pistolEvents:0,shotsHit:0,punchEvents:0,punchHits:0,punchMisses:0,laggedAttacks:0,firstSubticEvents:0,secondSubticEvents:0,fistStates:0,weaponSwitching:0};
const examples={};
for(const seed of [9000,9001,9002]){
  let s=a.reset(seed), shots=0,hits=0,punches=0,punchHits=0,damage=0;
  for(let j=0;!s.done&&j<1051;j++){
    const t=s.threat;
    const aim=t.aligned?2:t.x<0?0:1;
    // Use the earlier engine diagnostic during the pistol phase. Exercise miss and
    // delayed swing callbacks with sparse attacks after the weapon changes.
    const action=s.weapon==='fist' && j%10<5 ? 2 : aim;
    const previous=s;
    s=a.step(action,seed===9000 || t.visible && t.distance<208 && t.backClearance>24);
    checkPose(s);
    const e=s.events;
    assert.equal(e.healthBefore,previous.health);assert.equal(e.healthAfter,s.health);
    assert.equal(e.damage,e.damageBySubtic[0]+e.damageBySubtic[1]);
    assert.equal(e.damage,e.healthBefore-e.healthAfter);
    assert.equal(e.shots.length,previous.ammo-s.ammo);
    assert.ok(['pistol','fist'].includes(s.weapon));
    if(s.weaponReady)assert.ok(!s.weaponSwitching&&s.health>0&&(s.weapon==='fist'||s.ammo>0));
    for(const [kind,events] of [['pistol',e.shots],['punch',e.punches]]){
      for(const ev of events){
        assert.ok(ev.tic>previous.tic&&ev.tic<=s.tic);
        assert.equal(ev.hit,ev.targetId>0);
        ev.tic===previous.tic+1?totals.firstSubticEvents++:totals.secondSubticEvents++;
        if(action!==2){totals.laggedAttacks++;examples.delayed??={seed,requestedAction:action,kind,...ev};}
        if(kind==='punch') examples[ev.hit?'punchHit':'punchMiss']??={seed,...ev};
      }
    }
    shots+=e.shots.length;hits+=e.shots.filter(x=>x.hit).length;
    punches+=e.punches.length;punchHits+=e.punches.filter(x=>x.hit).length;damage+=e.damage;
    totals.observations++;totals.visibleActorObservations+=s.actors.length;
    totals.fistStates+=Number(s.weapon==='fist');totals.weaponSwitching+=Number(s.weaponSwitching);
    if(!previous.actors.length)totals.damageWhileNoVisibleActor+=e.damage;
  }
  assert.ok(s.done);
  assert.equal(s.telemetry.shots,shots);assert.equal(s.telemetry.hits,hits);
  assert.equal(s.telemetry.punches,punches);assert.equal(s.telemetry.punchHits,punchHits);
  assert.equal(s.telemetry.punchMisses,punches-punchHits);assert.equal(s.telemetry.damageTaken,damage);
  totals.pistolEvents+=shots;totals.shotsHit+=hits;totals.punchEvents+=punches;totals.punchHits+=punchHits;
  totals.punchMisses+=punches-punchHits;totals.damage+=damage;
}
for(const k of ['observations','pistolEvents','shotsHit','punchEvents','punchHits','punchMisses','firstSubticEvents','secondSubticEvents','laggedAttacks','damage','fistStates','weaponSwitching'])assert.ok(totals[k]>0,`Missing ${k}`);
console.log(JSON.stringify({purpose:'engine sensing/actuation test; scripted diagnostic, not a Kumo gameplay result',movements,totals,examples},null,2));
