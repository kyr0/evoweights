/* Public sensor contract and a controlled counterexample to time-facing-only damage. */
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createArena} from '../dist/arena.mjs';

const readAsset = name => readFile(new URL('../dist/'+name,import.meta.url));
const arena = await createArena({seed:9000,readAsset});
const wasm = await WebAssembly.compile(await readAsset('arena.wasm'));
assert.ok(WebAssembly.Module.exports(wasm).every(x=>!x.name.includes('bite')));
const counts = {states:0,actorRows:0,empty:0,lookingTowardButOffCrosshair:0,onCrosshairButLookingAside:0};
let longestFacingRun, absenceThenReappearance=false;
const initial = arena.state().actors[0];
assert.equal(initial.id,3);
assert.equal(initial.yawDeg,135);
assert.ok(Math.abs(initial.facingErrorDeg - 29.9918329111199)<1e-6);
for(const seed of [9000,9001,9002,9003,9004,9005]){
  let state = arena.reset(seed);
  const runs = new Map(), lastSeen = new Map();
  while(!state.done && state.tic<550){
    counts.states++;
    assert.equal(state.actors.length,state.threat.visibleCount);
    const hasVisiblePixels = state.features.slice(0,9).some(value=>value>0);
    assert.equal(state.actors.length>0,hasVisiblePixels);
    if(!hasVisiblePixels)counts.empty++;
    const visibleIds = new Set();
    for(const actor of state.actors){
      counts.actorRows++;
      assert.ok(!visibleIds.has(actor.id));
      visibleIds.add(actor.id);
      const dx = state.x-actor.worldX, dy = state.y-actor.worldY;
      const yaw = actor.yawDeg*Math.PI/180, distance = Math.hypot(dx,dy);
      assert.ok(actor.yawDeg>=0 && actor.yawDeg<360);
      assert.ok(actor.facingErrorDeg>=-180 && actor.facingErrorDeg<180);
      const dot = (dx*Math.cos(yaw) + dy*Math.sin(yaw))/distance;
      const cross = (dy*Math.cos(yaw) - dx*Math.sin(yaw))/distance;
      assert.ok(Math.abs(dot-actor.facingCos)<1e-10);
      assert.ok(Math.abs(cross-Math.sin(actor.facingErrorDeg*Math.PI/180))<1e-10);
      if(Math.abs(actor.facingErrorDeg)<10 && !actor.aligned)counts.lookingTowardButOffCrosshair++;
      if(Math.abs(actor.facingErrorDeg)>25 && actor.aligned)counts.onCrosshairButLookingAside++;
      if(lastSeen.has(actor.id) && lastSeen.get(actor.id)<state.tic-2)absenceThenReappearance=true;
      lastSeen.set(actor.id,state.tic);
      if(Math.abs(actor.facingErrorDeg)<=15 && distance>110 && !state.events.damage){
        const start=runs.get(actor.id)??state.tic;
        runs.set(actor.id,start);
        const duration=state.tic-start;
        if(!longestFacingRun || duration>longestFacingRun.tics)
          longestFacingRun={seed,id:actor.id,start,end:state.tic,tics:duration};
      }else runs.delete(actor.id);
    }
    for(const id of runs.keys())if(!visibleIds.has(id))runs.delete(id);
    const t=state.threat;
    // Turn on two seeds to observe disappearing and reappearing lives.
    const aim=seed%3===0?3:seed%3===1?0:t.visible&&!t.aligned?(t.x<0?0:1):3;
    const back=seed%3===2 && t.visible && t.distance<180;
    state=arena.step(aim,back);
  }
}
assert.ok(counts.empty>0 && absenceThenReappearance);
assert.ok(counts.lookingTowardButOffCrosshair>0 && counts.onCrosshairButLookingAside>0);
assert.ok(longestFacingRun.tics>=22,'No at-distance continuous facing counterexample');
console.log(JSON.stringify({initial,counts,absenceThenReappearance,longestFacingRun,
  farRunDefinition:'Same rendered life within 15 degrees at every two-tic sample, distance >110 at every sample, zero health lost on every intervening tic. Endpoints tics at 35 Hz.'},null,2));
