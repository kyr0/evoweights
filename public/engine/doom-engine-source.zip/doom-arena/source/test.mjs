/* Node 22+, same ECMAScript WebAssembly API and JS host used by the browser worker. */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {createArena} from '../dist/arena.mjs';
const engine=await createArena({readAsset:n=>readFile(new URL('../dist/'+n,import.meta.url)),seed:9000});
const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const start=hash(engine.frame());
assert.equal(engine.frame().length,320*200*4);
assert.equal(engine.state().ammo,26);
assert.equal(engine.state().health,100);
assert.equal(engine.state().features.length,14);
function rollout(seed, actions){
  engine.reset(seed);
  for(const act of actions)engine.step(act);
  const s=engine.state();
  return {tic:s.tic, kills:s.kills, ammo:s.ammo, health:s.health,frame:hash(engine.frame()),features:[...s.features]};
}
const actions=Array.from({length:64},(_,i)=>i%4===0?2:1);
const first=rollout(9000,actions),repeat=rollout(9000,actions);
assert.deepEqual(first,repeat);
const mirrored=rollout(9000,actions.map(i=>i===1?0:i));
assert.notEqual(first.frame,mirrored.frame);
assert.notDeepEqual(first.features.slice(0,9),mirrored.features.slice(0,9));
assert.equal(first.tic,128);
assert.equal(first.features[12],1);
assert.equal(first.features[11],0);
assert.ok(first.ammo<26 && first.ammo>=0);
engine.reset(9231);assert.notEqual(hash(engine.frame()),start);
engine.reset(9000);assert.equal(hash(engine.frame()),start);
let s=engine.state(),steps=0;
while(!s.done && steps++ <1100){
 const f=s.features;
 const action=f[4]>.001?2: f.slice(0,4).reduce((a,b)=>a+b,0)>f.slice(5,9).reduce((a,b)=>a+b,0)?0:1;
 s=engine.step(action);
 assert.ok(s.features.slice(0,9).every(x=>Number.isFinite(x)&&x>=0&&x<=1));
}
assert.ok(s.done);assert.ok(s.kills>0);
console.log(JSON.stringify({seed:9000,firstFrame:start,actionReplay:first.frame,leftInsteadOfRight:mirrored.frame,
  testPolicy:'engine verification only: deterministic horizontal-region heuristic',
  smoke:{steps,tics:s.tic,kills:s.kills,ammo:s.ammo,health:s.health},sameSeedReplay:true,actionDivergence:true,seedDivergence:true},null,2));
