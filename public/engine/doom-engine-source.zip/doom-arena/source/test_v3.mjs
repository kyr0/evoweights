/* Same-seed simulator measurements; no model or trained-policy scores. */
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createArena} from '../dist/arena.mjs';
const game=await createArena({seed:9000,readAsset:n=>readFile(new URL('../dist/'+n,import.meta.url))});
const {threat:initial}=game.state();
assert.ok(initial.visible && initial.distance>500 && initial.backClearance>600);
assert.equal(initial.closing,0);
function first16(back){
  game.reset(9000);
  for(let i=0;i<8;i++)game.step(2,back);
  const s=game.state();
  return {x:s.x,y:s.y,angle:s.angle,ammo:s.ammo,health:s.health,retreatDisplacement:s.telemetry.retreatDisplacement};
}
const frozen=first16(false),retreat=first16(true);
assert.equal(frozen.x,0);assert.equal(frozen.y,0);
assert.ok(retreat.x< -30 && Math.abs(retreat.y)<1);
assert.ok(retreat.ammo<26 && frozen.ammo===retreat.ammo);
assert.deepEqual(retreat,first16(true));
const tasks={};
for(const [i,n] of ['left','right','fire'].entries()){
  game.reset(9000);
  for(let j=0;j<12;j++)game.step(i,true);
  const s=game.state();
  assert.ok(s.telemetry.retreatDisplacement>10);
  tasks[n]={angle:s.angle,displacement:s.telemetry.retreatDisplacement,shots:s.telemetry.shots};
}
assert.notEqual(tasks.left.angle,tasks.right.angle);
assert.equal(tasks.left.shots,0);assert.equal(tasks.right.shots,0);assert.ok(tasks.fire.shots>0);
let multi=0,adverse=0,targets=new Set(),wallLimited=false,observations=0,checkedClosing=0;
for(let seed=9000;seed<9003;seed++){
  game.reset(seed);let previous=null;
  for(let j=0;j<1000 && !game.state().done;j++){
    const s=game.state(),t=s.threat;
    assert.equal(t.visible,s.features.slice(0,9).some(x=>x>0));
    assert.ok(t.x>=-1 && t.x<=1 && t.backClearance>=0);
    if(t.visible){
      assert.ok(t.id>0 && t.distance>0);targets.add(t.id);
      if(previous && previous.threat.id===t.id){
        assert.ok(Math.abs(t.closing-(previous.threat.distance-t.distance)/(s.tic-previous.tic))<.001);checkedClosing++;
      }
    }else{
      assert.equal(t.id,0);assert.equal(t.closing,0);assert.equal(t.aligned,false);
    }
    if(t.visibleCount>=2)multi++;
    if(t.closing<0)adverse++;
    previous=s;observations++;
    if(t.backClearance<40)wallLimited=true;
    game.step(t.aligned?2:t.x<0?0:1,seed===9000 || t.visible && t.distance<208 && t.backClearance>24);
  }
}
assert.ok(targets.size>5 && multi>0 && adverse>0 && checkedClosing>0);
const t=game.state().telemetry;
assert.ok(t.hits>0 && t.nearestHits>0 && t.multiHits>0);
assert.ok(t.shots>=t.hits && t.hits>=t.nearestHits && t.multiShots>=t.multiHits && t.multiHits>=t.multiNearestHits);
console.log(JSON.stringify({testPolicy:"sensor-driven engine diagnostics, no neural policy",initialThreat:initial,after16Tics:{fire:frozen,fireAndBack:retreat},actions:tasks,observations,checkedClosing,multi,distinctSpawnIds:targets.size,observedWallLimited:wallLimited,actualHitscanTelemetry:t},null,2));
